<!-- login.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./estilos/estilosLogin.css">
</head>

<body class="body-login">
    <div class="login-container">
        <div class="profile-icon">
            <div class="circle">
                <div class="icon"></div>
            </div>
        </div>

        <form class="login-form" method="POST" action="verificar_login.php">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">INGRESAR</button>
        </form>

        <div class="options">
            <a href="#">¿Olvidaste tu contraseña?</a>
            <a href="registrarse.php" class="register">Registrarse</a>
        </div>
    </div>
</body>
</html>
