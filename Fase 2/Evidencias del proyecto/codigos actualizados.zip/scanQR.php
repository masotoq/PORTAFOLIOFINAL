<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

$categoria = isset($_GET['categoria']) ? htmlspecialchars($_GET['categoria']) : 'Desconocida';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>QR Scanner - <?php echo $categoria; ?></title>
  <link rel="stylesheet" href="./estilos/estiloQR.css">
  <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
  <script src="./script.js" defer></script>
</head>

<body>
  <div class="header">
    <button class="back-button" onclick="location.href='seleccionCategoria.php'">
      &#x21A9; Volver
    </button>
  </div>

  <h1>SCAN - <?php echo $categoria; ?></h1>
  <div id="reader" class="responsive-scanner"></div>
  <div id="result">Esperando escaneo...</div>
  <button class="button" onclick="startScanner()">Iniciar Escáner</button>
</body>
</html>

