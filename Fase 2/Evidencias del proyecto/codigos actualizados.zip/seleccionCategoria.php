<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Categoría</title>
    <link rel="stylesheet" href="./estilos/estiloSeleccionCat.css">

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <h1>Bienvenido <?php echo htmlspecialchars($_SESSION['nombre_usuario']); ?></h1>
        <h1>Elige una opción para el scan:</h1>

        <div class="categories">
            <button onclick="navigateToQR('Notebook')">Notebook</button>
            <button onclick="navigateToQR('Monitores')">Monitores</button>
            <button onclick="navigateToQR('CPU')">CPU</button>
            <button onclick="navigateToQR('Teclados')">Teclados</button>
            <button onclick="navigateToQR('Mouse')">Mouse</button>
            <button onclick="navigateToQR('Impresoras')">Impresoras</button>
            <button onclick="navigateToQR('Router')">Router</button>
        </div>

        <!-- Botón de cerrar sesión con SweetAlert2 -->
        <button class="cerrarSesion" type="button" id="cerrarSesionBtn">Cerrar Sesión</button>
    </div>

    <script>
        function navigateToQR(categoria) {
            window.location.href = 'scanQR.php?categoria=' + encodeURIComponent(categoria);
        }

        document.getElementById('cerrarSesionBtn').addEventListener('click', function () {
            Swal.fire({
                title: '¿Deseas cerrar sesión?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, cerrar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        });
    </script>
</body>
</html>

