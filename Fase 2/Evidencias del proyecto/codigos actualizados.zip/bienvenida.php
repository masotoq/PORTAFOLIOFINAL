<?php
session_start();
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenida</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <script>
        Swal.fire({
            title: '¡Bienvenido!',
            text: '<?php echo $_SESSION["nombre_usuario"]; ?>',
            icon: 'success',
            confirmButtonText: 'Continuar',
            timer: 2500,
            timerProgressBar: true,
            allowOutsideClick: false,
            allowEscapeKey: false
        }).then(() => {
            window.location.href = 'seleccionCategoria.php';
        });
    </script>
</body>
</html>
