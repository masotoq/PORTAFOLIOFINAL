<?php
require 'conexion.php';

$mensajeJS = ""; // Usamos esta variable para guardar los mensajes JS dinámicos

// Procesar el formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre_usuario = $_POST['nombre_usuario'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmar_password = $_POST['confirmar_password'];

    if ($password !== $confirmar_password) {
        $mensajeJS = "Swal.fire({
            icon: 'warning',
            title: 'Las contraseñas no coinciden',
            confirmButtonColor: '#1abc5b'
        });";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios (nombre_usuario, email, contraseña) VALUES (:nombre, :email, :pass)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre_usuario);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':pass', $hash);

        try {
            $stmt->execute();
            $mensajeJS = "Swal.fire({
                icon: 'success',
                title: 'Registro exitoso',
                text: 'Ahora puedes iniciar sesión.',
                confirmButtonColor: '#1abc5b'
            }).then(() => {
                window.location.href = 'login.php';
            });";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $mensajeJS = "Swal.fire({
                    icon: 'error',
                    title: 'Correo ya registrado',
                    text: 'Intenta con otro correo.',
                    confirmButtonColor: '#1abc5b'
                });";
            } else {
                $mensajeJS = "Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: '" . $e->getMessage() . "',
                    confirmButtonColor: '#1abc5b'
                });";
            }
        }
    }
}
?>

<!-- HTML del formulario -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="./estilos/estilosLogin.css">
    <!-- SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="body-login">
    <div class="login-container">
        <div class="top-bar">
            <a href="login.php" class="volver">
                <span class="icono-volver">⟲</span> Regresar
            </a>
        </div>

        <div class="profile-icon">
            <div class="circle">
                <div class="icon"></div>
            </div>
        </div>

        <form class="login-form" method="POST" action="">
            <input type="text" name="nombre_usuario" placeholder="Nombre de Usuario" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <input type="password" name="confirmar_password" placeholder="Confirmar Contraseña" required>
            <button type="submit">REGISTRARSE</button>
        </form>
    </div>

    <?php if (!empty($mensajeJS)) : ?>
        <script>
            <?= $mensajeJS ?>
        </script>
    <?php endif; ?>
</body>
</html>

