<?php
session_start();
require 'conexion.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Busca el usuario por email
$sql = "SELECT * FROM usuarios WHERE email = :email LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':email', $email);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

// Verifica contraseña
if ($usuario && password_verify($password, $usuario['contraseña'])) {
    $_SESSION['email'] = $usuario['email'];
    $_SESSION['nombre_usuario'] = $usuario['nombre_usuario'];
    header("Location: bienvenida.php");
    exit();
} else {
    echo "<script>alert('Correo o contraseña incorrectos'); window.location.href='login.php';</script>";
}
?>
