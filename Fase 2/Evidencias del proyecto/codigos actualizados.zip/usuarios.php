<?php
// usuarios.php
return [
    [
        "email" => "admin@empresa.cl",
        "password" => "1234"
    ],
    [
        "email" => "usuario@empresa.cl",
        "password" => "abcd"
    ]
];
