<?php
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['id']) && isset($_POST['estado'])) {
        $id = intval($_POST['id']);
        $estado = trim($_POST['estado']);

        $sql = "UPDATE inventario SET estado = :estado WHERE id = :id";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute(['estado' => $estado, 'id' => $id])) {
            echo "OK";
        } else {
            $error = $stmt->errorInfo();
            echo "Error al actualizar: " . $error[2];
        }
    } else {
        echo "Datos incompletos";
    }
}
?>
