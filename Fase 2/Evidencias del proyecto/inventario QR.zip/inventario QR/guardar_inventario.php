<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo json_encode(["success" => false, "message" => "No autorizado"]);
    exit();
}

// Mostrar errores para depurar
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Obtener los datos enviados en formato JSON
$data = json_decode(file_get_contents("php://input"), true);

// Validar datos
if (!$data || !isset($data['categoria'], $data['marca'], $data['modelo'], $data['numero_serie'], $data['estado'])) {
    echo json_encode(["success" => false, "message" => "Datos incompletos"]);
    exit();
}

// Conexi��n a la base de datos
require 'conexion.php';

try {
    $sql = "INSERT INTO inventario (categoria, marca, modelo, numero_serie, estado, fecha_registro) 
            VALUES (:categoria, :marca, :modelo, :numero_serie, :estado, NOW())";
    
    $stmt = $conn->prepare($sql);
    
    $stmt->bindParam(':categoria', $data['categoria']);
    $stmt->bindParam(':marca', $data['marca']);
    $stmt->bindParam(':modelo', $data['modelo']);
    $stmt->bindParam(':numero_serie', $data['numero_serie']);
    $stmt->bindParam(':estado', $data['estado']);
    
    $stmt->execute();

    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
