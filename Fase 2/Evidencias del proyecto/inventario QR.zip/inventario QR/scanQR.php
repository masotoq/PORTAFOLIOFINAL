<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

$categoria = isset($_GET['categoria']) ? htmlspecialchars($_GET['categoria']) : 'Desconocida';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QR Scanner - <?php echo $categoria; ?></title>
  <link rel="stylesheet" href="./estilos/estiloQR.css">
  <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
  <div class="header">
    <button class="back-button" onclick="location.href='seleccionCategoria.php'">
      &#x21A9; Volver
    </button>
  </div>

  <h1>SCAN - <?php echo $categoria; ?></h1>
  <div id="reader" class="responsive-scanner"></div>
  <div id="result">Esperando escaneo...</div>
  <button class="button" onclick="startScanner()">Iniciar Escáner</button>

  <script>
  function startScanner() {
    const html5QrCode = new Html5Qrcode("reader");

    html5QrCode.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: 250 },
      qrCodeMessage => {
        document.getElementById("result").innerText = `Código escaneado: ${qrCodeMessage}`;

        const partes = qrCodeMessage.split("|");

        if (partes.length < 3) {
          Swal.fire({
            icon: 'error',
            title: 'QR inválido',
            text: 'El código QR debe contener al menos Marca, Modelo y Número de Serie.'
          });
          return;
        }

        const marca = partes[0].trim();
        const modelo = partes[1].trim();
        const numeroSerie = partes[2].trim();
        const estado = (partes[3] || "Disponible").trim();
        const categoria = "<?php echo $categoria; ?>";

        html5QrCode.stop().then(() => {
          document.getElementById("reader").innerHTML = "";

          fetch("guardar_inventario.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              categoria,
              marca,
              modelo,
              numero_serie: numeroSerie,
              estado
            })
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              Swal.fire({
                icon: 'success',
                title: 'Registro guardado',
                text: 'El inventario fue guardado correctamente.',
                timer: 1500,
                showConfirmButton: false
              });
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Error al guardar',
                text: data.message || 'Ocurrió un error al guardar el registro.'
              });
            }
          })
          .catch(error => {
            Swal.fire({
              icon: 'error',
              title: 'Error de red',
              text: 'No se pudo conectar con el servidor.'
            });
          });

        }).catch(err => {
          console.error("Error al detener el escáner: ", err);
          Swal.fire({
            icon: 'error',
            title: 'Error al detener cámara',
            text: 'El escáner no pudo detenerse correctamente.'
          });
        });
      },
      errorMessage => {
        console.log("Error al escanear: ", errorMessage);
      }
    );
  }
  </script>
</body>
</html>



