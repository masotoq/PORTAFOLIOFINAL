<?php
session_start();
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: login.php");
    exit();
}

require_once "conexion.php";

$sql = "SELECT id, marca, modelo, numero_serie, estado FROM inventario WHERE categoria = 'Monitores'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Monitores</title>
  <link rel="stylesheet" href="styles.css" />
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
  <div class="container">
    <aside class="sidebar" id="sidebar">
      <div class="user-info">
        <h2><?php echo $_SESSION['nombre_usuario']; ?></h2>
      </div>
      <nav class="menu">
        <a href="notebook.php"><span class="material-icons">laptop</span>Notebook</a>
        <a href="monitores.php"><span class="material-icons">desktop_windows</span>Monitores</a>
        <a href="CPU.php"><span class="material-icons">dns</span>CPU</a>
        <a href="teclados.php"><span class="material-icons">keyboard</span>Teclados</a>
        <a href="mouse.php"><span class="material-icons">mouse</span>Mouse</a>
        <a href="index.php"><span class="material-icons">print</span>Impresoras</a>
        <a href="router.php"><span class="material-icons">router</span>Router</a>
        <a href="seleccionCategoria.php" class="scan-button" target="_blank"><span class="material-icons">qr_code_scanner</span>SCAN</a>
      </nav>
      <button class="logout" type="button" id="cerrarSesionBtn">Cerrar Sesión</button>
    </aside>

    <div class="overlay" id="overlay"></div>

    <main class="content">
      <button class="menu-toggle" id="menuToggle">
        <span class="material-icons">menu</span>
      </button>

      <div class="header">
        <h1 class="tituloHeader">Monitores</h1>
        <span class="material-icons header-icon">desktop_windows</span>
      </div>

      <table class="printer-table">
        <thead>
          <tr>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Número de Serie</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($result): ?>
            <?php foreach ($result as $row): ?>
              <tr>
                <td><?= htmlspecialchars($row['marca']) ?></td>
                <td><?= htmlspecialchars($row['modelo']) ?></td>
                <td><?= htmlspecialchars($row['numero_serie']) ?></td>
                <td>
                  <select class="estado-select" data-id="<?= $row['id'] ?>">
                    <?php
                    $estados = [
                      "-","Gerencia", "RRHH", "Contabilidad y Finanzas", "Operaciones",
                      "Bodega", "TI / Soporte Técnico", "Defectuoso",
                      "Servicio Técnico", "Reciclaje", "Extraviado"
                    ];
                    foreach ($estados as $estado) {
                      $selected = $row['estado'] === $estado ? "selected" : "";
                      echo "<option value=\"$estado\" $selected>$estado</option>";
                    }
                    ?>
                  </select>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="4">No hay registros de monitores.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>

      <footer class="footer">
        <p>LOGO EMPRESA</p>
      </footer>
    </main>
  </div>

  <script src="script.js" defer></script>
</body>
</html>



