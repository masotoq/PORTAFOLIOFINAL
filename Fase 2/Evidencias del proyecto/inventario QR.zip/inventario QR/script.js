document.addEventListener("DOMContentLoaded", function () {
  // ----------------- ACTIVAR ENLACE ACTUAL -----------------
  const links = document.querySelectorAll(".menu a");
  const currentURL = window.location.href;
  links.forEach(link => {
    if (currentURL.includes(link.href)) {
      link.classList.add("active");
    }
  });

  // ----------------- TOGGLE DEL MENÚ -----------------
  const menuToggle = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const content = document.querySelector('.content');

  if (menuToggle && sidebar && overlay && content) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('hidden');
      overlay.style.display = sidebar.classList.contains('hidden') ? 'none' : 'block';

      if (sidebar.classList.contains('hidden')) {
        menuToggle.style.left = '20px';
        content.classList.add('expanded');
      } else {
        menuToggle.style.left = '270px';
        content.classList.remove('expanded');
      }
    });

    overlay.addEventListener('click', () => {
      sidebar.classList.add('hidden');
      overlay.style.display = 'none';
      menuToggle.style.left = '20px';
      content.classList.add('expanded');
    });
  }

  // ----------------- CERRAR SESIÓN -----------------
  const cerrarSesionBtn = document.getElementById('cerrarSesionBtn');
  if (cerrarSesionBtn) {
    cerrarSesionBtn.addEventListener('click', function () {
      Swal.fire({
        title: '¿Deseas cerrar sesión?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, cerrar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = 'logout.php';
        }
      });
    });
  }

  // ----------------- CAMBIO DE ESTADO (AJAX) -----------------
  document.querySelectorAll('.estado-select').forEach(select => {
    let valorInicial = select.value;

    select.addEventListener('focus', function () {
      valorInicial = this.value;
    });

    select.addEventListener('change', function () {
      if (this.value === valorInicial) return;

      const id = this.getAttribute('data-id');
      const nuevoEstado = this.value;

      fetch('actualizar_estado.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `id=${encodeURIComponent(id)}&estado=${encodeURIComponent(nuevoEstado)}`
      })
      .then(response => response.text())
      .then(data => {
        if (data.trim().toUpperCase() === "OK") {
          Swal.fire({
            icon: 'success',
            title: 'Estado actualizado',
            timer: 1200,
            showConfirmButton: false
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Error al actualizar',
            text: data
          });
        }
      })
      .catch(error => {
        Swal.fire({
          icon: 'error',
          title: 'Error de red',
          text: error.message
        });
      });
    });
  });

  // ----------------- GENERAR QR CON MARCA, MODELO Y N° SERIE -----------------
  function generarQR() {
    const marca = document.getElementById('marca').value.trim();
    const modelo = document.getElementById('modelo').value.trim();
    const numeroSerie = document.getElementById('numero_serie').value.trim();

    if (!marca || !modelo || !numeroSerie) {
      Swal.fire({
        icon: 'warning',
        title: 'Faltan datos',
        text: 'Por favor, completa Marca, Modelo y Número de Serie para generar el QR.'
      });
      return;
    }

    const qrData = `${marca}|${modelo}|${numeroSerie}`; // Solo 3 campos

    const qrDiv = document.getElementById('qrcode');
    qrDiv.innerHTML = "";

    new QRCode(qrDiv, {
      text: qrData,
      width: 256,
      height: 256,
      colorDark: "#000000",
      colorLight: "#ffffff",
      correctLevel: QRCode.CorrectLevel.H
    });
  }

  const btnGenerarQR = document.getElementById('btnGenerarQR');
  if (btnGenerarQR) {
    btnGenerarQR.addEventListener('click', generarQR);
  }
});

 